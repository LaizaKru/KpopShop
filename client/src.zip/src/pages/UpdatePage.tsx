import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import type { RootState } from '../redux/store';
import { useAppDispatch } from '../redux/store';
import type Card from '../redux/cards/types/card';
import CardComponent from '../components/Card';
import UpdateCardForm from '../components/UpdateCardForm';
import { useParams } from 'react-router';

function UpdatePage(): JSX.Element {
  const { id } = useParams();
  const [card, setCard] = useState<Card | null>(null);
  useEffect(() => {
    fetch(`/api/cards/${id}`, {
      headers: { 'Content-type': 'application/json' },
    })
      .then((res) => res.json())
      .then((data: { card: Card }) => setCard(data.card));
  }, []);
  if (!card) {
    return <div>Загрузка</div>;
  }
  return <UpdateCardForm card={card} />;
}
export default UpdatePage;
