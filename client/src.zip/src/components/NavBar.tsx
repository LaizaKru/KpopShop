import React from 'react';
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';
import { RootState, useAppDispatch } from '../redux/store';
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import BootStrapNavbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Button from 'react-bootstrap/Button';

function NavBar(): JSX.Element {
  const user = useSelector((state: RootState) => state.auth.user);
  const dispatch = useAppDispatch();
  const handleLogout = () => dispatch({ type: 'auth/logout' });

  return (
    <BootStrapNavbar expand="lg" className="bg-body-tertiary">
      <Container>
        <BootStrapNavbar.Brand href="#home">KPOP shop</BootStrapNavbar.Brand>
        {user ? (
          <div>
            <Button type="button" onClick={handleLogout}>
              Выйти
            </Button>
            <Link to={'/notes'}> Мои заметки</Link>
          </div>
        ) : (
          <div>
            {' '}
            <Link to={'/login'}> Войти</Link> <Link to={'/reg'}>Зарегистрироваться </Link>
          </div>
        )}
      </Container>
    </BootStrapNavbar>
  );
}
export default NavBar;
