import React from 'react';
import { Link } from 'react-router-dom';
import type Card from '../redux/cards/types/card';
import Button from 'react-bootstrap/Button';
import BootCard from 'react-bootstrap/Card';

import { useAppDispatch } from '../redux/store';

type CardPropsType = {
  card: Card;
};

function CardComponent({ card }: CardPropsType): JSX.Element {
  const dispatch = useAppDispatch();
  const handleRemove = async (id: Card['id']): Promise<void> => {
    // кинула запрос на сервер (тот удалит из бд)
    const response = await fetch(`/api/cards/${id}`, {
      method: 'DELETE',
    });
    if (response.ok) {
      dispatch({ type: 'card/delete', payload: card });
    }
    // дожидаюсь ответа  - от сервера пришла айди удеаленной вакансии
    //  меняю стейт
  };
  return (
    <BootCard style={{ width: '18rem' }}>
      <BootCard.Img variant="top" src={card.img} />
      <BootCard.Body>
        <BootCard.Title>
          <Link to={`/cards/${card.id}`}>
            <h4>{card.artist}</h4>
          </Link>
        </BootCard.Title>
        <BootCard.Text>{card.price}</BootCard.Text>
        <Button type="button" onClick={() => handleRemove(card.id)}>
          Удалить
        </Button>
      </BootCard.Body>
    </BootCard>
  );
}

export default CardComponent;
