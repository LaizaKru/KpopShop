import React, { useState } from 'react';
import { useAppDispatch } from '../redux/store';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';

export default function AddCardForm(): JSX.Element {
  const [artist, setArtist] = useState('');
  const [img, setImg] = useState('');
  const [price, setPrice] = useState(0);
  const dispatch = useAppDispatch();

  const handleSubmit: React.FormEventHandler<HTMLFormElement> = async (e) => {
    e.preventDefault();
    const response = await fetch('/api/cards', {
      method: 'POST',
      body: JSON.stringify({ price, artist, img }),
      headers: { 'Content-type': 'application/json' },
    });
    const data = await response.json();
    if (data.success) {
      dispatch({ type: 'card/add', payload: data.card });
      setArtist('');
      setImg('');
      setPrice(0);
    }
  };
  return (
    <div className="container">
      <Form onSubmit={handleSubmit}>
        <h4>Добавить карточку</h4>
        <Form.Group>
          <Form.Label>название ариста:</Form.Label>
          <Form.Control
            type="text"
            name="artist"
            value={artist}
            onChange={(e) => setArtist(e.target.value)}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label>Фото:</Form.Label>
          Фото:
          <Form.Control
            type="text"
            name="img"
            value={img}
            onChange={(e) => setImg(e.target.value)}
          />
        </Form.Group>
        <Form.Group>
          <Form.Label>Цена:</Form.Label>
          <Form.Control
            type="number"
            className="form-control"
            value={price}
            onChange={(e) => setPrice(+e.target.value)}
          />
        </Form.Group>
        <Button type="submit" className="btn btn-primary" style={{ marginTop: '10px' }}>
          Добавить
        </Button>
      </Form>
    </div>
  );
}
