import React, { useState } from 'react';
import { useAppDispatch } from '../redux/store';
import type Card from '../redux/cards/types/card';
import { useNavigate } from 'react-router';

type UpdateCardFormPropTypes = {
  card: Card;
};

export default function UpdateCardForm({ card }: UpdateCardFormPropTypes): JSX.Element {
  const [artist, setArtist] = useState(card.artist);
  const [img, setImg] = useState(card.img);
  const [price, setPrice] = useState(card.price);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { id } = card;
  const handleSubmit: React.FormEventHandler<HTMLFormElement> = async (e) => {
    e.preventDefault();
    const response = await fetch(`/api/cards/${id}`, {
      method: 'PUT',
      body: JSON.stringify({ price, artist, img }),
      headers: { 'Content-type': 'application/json' },
    });
    const data = await response.json();
    if (data.success) {
      dispatch({ type: 'card/update', payload: data.card });
      navigate('/cards');
    }
  };
  return (
    <div className="container">
      <form onSubmit={handleSubmit}>
        <h4>Изменить карточку</h4>
        <div>
          <label>
            название ариста:
            <input
              type="text"
              name="artist"
              value={artist}
              onChange={(e) => setArtist(e.target.value)}
            />
          </label>
        </div>
        <div className="form-group">
          <label>
            Фото:
            <input type="text" name="img" value={img} onChange={(e) => setImg(e.target.value)} />
          </label>
        </div>
        <div className="form-group">
          <label>
            Цена:
            <input
              type="number"
              className="form-control"
              value={price}
              onChange={(e) => setPrice(+e.target.value)}
            />
          </label>
        </div>
        <button type="submit" className="btn btn-primary" style={{ marginTop: '10px' }}>
          Изменить
        </button>
      </form>
    </div>
  );
}
