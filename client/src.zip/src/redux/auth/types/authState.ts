import User from './user';

type AuthState = {
  user: User | null;
};

export default AuthState;
