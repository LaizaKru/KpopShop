type User = {
  email: string;
  name: string;
  password: string;
};
export default User;
