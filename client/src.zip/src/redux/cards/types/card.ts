type Card = {
  artist: string;
  img: string;
  price: number;
  id: number;
};
export default Card;
