import type Card from './card';

type CardState = { cards: Card[] };

export default CardState;
